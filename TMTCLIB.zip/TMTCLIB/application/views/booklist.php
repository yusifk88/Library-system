<div class="table-responsive">
    <table class="table table-hover table-striped table-condense">
    <thead class="bg-success text-white">
        <tr>
            <th>S/N</th>
            <th>Book Title</th>
            <th>Author(s)</th>
            <th>Shelf/Location</th>
            <th>Copies</th>
            <th>Access No.</th>
            <th>ISBN</th>
            <th>Number Damaged</th>
            <th>Number Missing</th>
            <th>Number Lent</th>
            <th>Number Available</th>
            <th colspan="4">Action</th>
        </tr>
    </thead>
<tbody>
<?php
$i =1;
    foreach($books as $book){
        ?>
        <tr id="brow_<?=$book->id?>">
            <td><?=$i?></td>
            <td><?=highlight_phrase($book->title, $search, '<span style="background-color:greenyellow;">', '</span>');?></td>
            <td><?=highlight_phrase($book->authors, $search, '<span style="background-color:greenyellow;">', '</span>');?></td>
            <td><?=highlight_phrase($book->shelf, $search, '<span style="background-color:greenyellow;">', '</span>');?></td>
            <td><?=$book->copies?></td>
            <td><?=$book->accno?></td>
            <td><?=$book->isbn?></td>
            <td><?=$book->numdamage?></td>
            <td><?=$book->nummissing?></td>
            <td><?=$book->numlent?></td>
            <td><?=($book->copies-($book->nummissing + $book->numdamage+$book->numlent))?></td>
            <td>
                <button title="Edit this book" class="btn btn-outline-success btn-sm"  onclick="lend_book(<?=$book->id?>)">
                    <i class="fa fa-handshake-o"></i> Lend Book
                </button>
                </td>
            <td>

            <td>
                <button title="Edit this book" class="btn btn-outline-success btn-sm"  onclick="edit_book(<?=$book->id?>)">
                    <i class="fa fa-edit"></i>
                </button>
                </td>
            <td>

                <button onclick="change_damaged(<?=$book->id?>,<?=$book->copies-($book->nummissing + $book->numdamage)?>,<?=$book->numdamage?>)" title="Record Damaged copies" class="btn btn-outline-warning btn-sm">
                    <i class="fa fa-warning"></i>
                </button>

            </td>
            <td>
                <button onclick="change_missing(<?=$book->id?>,<?=$book->copies-($book->nummissing + $book->numdamage)?>,<?=$book->nummissing?>)" title="Record Missing copies" class="btn btn-outline-warning btn-sm">
                    <i class="fa fa-thermometer-empty"></i>
                </button>
            </td>

            <td>
                <button onclick="del_book(<?=$book->id?>)" class="btn btn-outline-danger btn-sm" title="Delete this record">
                    <i class="fa fa-remove"></i>
                </button>
            </td>
        </tr>
        <?php
        $i++;
    }

$next = $page+1;
$prev = $page -1;
?>
</tbody>
    </table>
</div>
<?php
if($pages>1){
if($page > 1) {
    ?>
    <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#managbooks/1">First Page</a>
    <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#managbooks/<?= $prev ?>"><<
        Prev.</a>
    <?php
    }
    for($i =1; $i<=$pages;$i++){
       if($page == $i){
           ?>
           <a  class="btn btn-success btn-sm">Page <?=$i?></a>
           <?php
       }else{
        ?>
        <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#managbooks/<?=$i?>">Page<?=$i?></a>

        <?php
    }}

if($page <$pages) {
    ?>
    <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#managbooks/<?= $next ?>">Next
        >> </a>
    <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#managbooks/<?= $pages ?>">Last
        Page</a>
    <?php
}}
    ?>