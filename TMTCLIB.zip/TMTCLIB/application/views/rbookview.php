<div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12">
            <ul class="list-group list-group-flush">
            <li class=" list-group-item"><strong><?=$book->stname?></strong><br><small>Name</small></li>
            <li class=" list-group-item"><strong><?=$book->stid?></strong><br><small>Index</small></li>
            <li class=" list-group-item"><strong><?=$book->dlend?></strong><br><small>Date Borrowed</small></li>
            <li class=" list-group-item"><strong><?=$book->dreturn?></strong><br><small>Expected Return Date</small></li>
            <li class=" list-group-item list-group-item-danger">NOT RETURNED</li>
        </ul>

    </div>
    <div class="col-lg-6 col-md-6 col-sm-12">
        <ul class="list-group list-group-flush">
            <li class=" list-group-item"><strong><?=$book->title?></strong><br><small>Title</small></li>
            <li class=" list-group-item"><strong><?=$book->authors?></strong><br><small>Author(s)</small></li>
            <li class=" list-group-item"><strong><?=$book->shelf?></strong><br><small>Shlef/Location</small></li>
            <li class=" list-group-item"><strong><?=$book->accno?></strong><br><small>Access Number</small></li>
            <li class=" list-group-item"><div class="md-form form-sm">
                    <i class="fa fa-calendar-plus-o prefix"></i>
                    <input value="" required type="date" id="rdate" class="form-control form-control-sm" name="rdate">
                    <label class="active" for="rdate">Date Returned</label>
                </div>
            </li>
        </ul>
    </div>
</div>
