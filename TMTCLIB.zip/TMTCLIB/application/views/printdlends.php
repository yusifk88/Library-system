<html>
<head>
    <title>List of books in Library</title>
    <link href="<?=base_url()?>assets/css/bootstrap-print.css" rel="stylesheet">
    <style>
        table, th, tr, td,tbody{
            border:1px solid #000 !important;
            background-color: transparent !important;
            -webkit-background-color: transparent !important;
        }
        /*@media print{*/
        /*table, th, tr, td{*/
        /*border:1px solid #000 !important;*/
        /*background-color: transparent !important;*/
        /*-webkit-background-color: transparent !important;*/
        /*}*/

        /*}*/

    </style>
</head>
<body>
<div class="container">
    <div class="row text-center">
        <h2>TUMU MIDWIFERY TRAINING COLLEGE</h2>
        <h3 class="text-capitalize">List of Library Defaulters</h3>
        <hr style="border: 0.5px solid #000 !important;">
    </div>
    <table class="table table-condensed">
        <thead>
        <tr class="text-capitalize">
            <th class="text-center">S/N</th>
            <th>NAME</th>
            <th>INDEX NO.</th>
            <th>BOOK</th>
            <th class="text-center">DATE LENT</th>
            <th class="text-center">EXPECTED <br>RETURN DATE</th>
            <th class="text-center">RETURN STATUS</th>
            <th class="text-center">DATE <br> RETURNED</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $i = 1;
        foreach($dlendlist as $list){
            ?>
            <tr>
                <td class="text-center"><?=$i?></td>
                <td><?=$list->stname?></td>
                <td><?=$list->stid?></td>
                <td><?=$list->title?></td>
                <td class="text-center"><?=$list->dlend?></td>
                <td class="text-center"><?=$list->dreturn?></td>
                <td class="text-center"><?=$list->return_status?"RETURNED":"NOT RETURNED"?></td>
                <td class="text-center"><?=$list->return_date? $list->return_date:' - '?></td>
            </tr>
            <?php
            $i++;
        }
        ?>
        </tbody>
    </table>
    <button class="btn btn-success hidden-print" onclick="window.print();">Print</button>
</div>
</body>
</html>