<?php
foreach( $lendhist as $hist) {
    ?>
    <ul class="list-group list-group-flush">
        <li class="list-group-item">
            <?=$hist->title?> <br>
            <small class="text-muted"><?=$hist->dlend?></small>
            <br>
            <?php
                if($hist->return_status){
                    ?>
                    <label for="" class="bg-success text-white p-2"><small>Returned</small></label>
                    <?php

                }else{
                    ?>
                    <label for="" class="bg-danger text-white"><small>Not Returned</small></label>


                    <?php

                }

            ?>


        </li>
    </ul>
    <?php
}
?>