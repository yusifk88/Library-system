<div class="row ">
    <div class="bg-success col-lg-3 col-md-3 text-center border-right text-white p-3">
        <h3><?=$dbooks?></h3>
        <i class="fa fa-book fa-3x"></i> <br>
        Books

    </div>

    <div class="bg-success col-lg-3 col-md-3 text-center border-right text-white p-3">
        <h3><?=$dusers?></h3>
        <i class="fa fa-users fa-3x"></i> <br>
        User

    </div>
    <div class="bg-success col-lg-3 col-md-3 text-center border-right text-white p-3">
        <h3><?=$dlend?></h3>
        <i class="fa fa-history fa-3x"></i> <br>
        Books Lent

    </div>

    <div class="bg-danger col-lg-3 col-md-3 text-center text-white p-3">
        <h3><?=$dunr?></h3>
        <i class="fa fa-user-times fa-3x"></i> <br>
        Unreturned Books
    </div>




</div>


<div class="row">
    <div class="bg-danger col-lg-3 col-md-3 text-center text-white p-3">
        <h3><?=$ddamage?></h3>
        <i class="fa fa-warning fa-3x"></i> <br>
        Damaged Books

    </div>
    <div class="col-lg-3 col-md-3 text-center border-right text-white p-3 bg-warning">
        <h3><?=$dbooks?></h3>
        <i class="fa fa-remove fa-3x"></i> <br>
        Missing Books

    </div>


</div>


