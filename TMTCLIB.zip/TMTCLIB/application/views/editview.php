<form action="" id="frmeditbook" onsubmit="savechanges(); return false;">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="md-form form-sm">
                <i class="fa fa-language prefix"></i>
                <input name="id" type="hidden" value="<?=$book->id?>">
                <input value="<?=$book->title?>" required type="text" id="title" class="form-control form-control-sm" name="title">
                <label class="active" for="title">Book Title</label>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="md-form form-sm">
                <i class="fa fa-users prefix"></i>
                <input value="<?=$book->authors?>" required type="text" id="author" name="authors" class="form-control form-control-sm">
                <label class="active" for="author">Author(s)</label>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4 col-md-4">
            <div class="md-form form-sm">
                <i class="fa fa-star-half-empty prefix"></i>
                <input value="<?=$book->copies?>" required min="0" type="number" id="qty" name="qty" class="form-control form-control-sm">
                <label class="active" for="qty">Copies</label>
            </div>
        </div>


        <div class="col-lg-4 col-md-4">
            <div class="md-form form-sm">
                <i class="fa fa-balance-scale prefix"></i>
                <input value="<?=$book->shelf?>" required type="text" id="qty" name="shelf" class="form-control form-control-sm">
                <label class="active" for="shelf">Shelf</label>
            </div>
        </div>

        <div class="col-lg-4 col-md-4">
            <div class="md-form form-sm">
                <i class="fa fa-hashtag prefix"></i>
                <input value="<?=$book->accno?>" required type="text" id="accno" name="accno" class="form-control form-control-sm">
                <label class="active" for="accno">ACC No.</label>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="md-form form-sm">
                <i class="fa fa-barcode prefix"></i>
                <input value="<?=$book->isbn?>" required type="text" id="isbn" name="isbn" class="form-control form-control-sm">
                <label class="active" for="isbn">ISBN</label>
            </div>
        </div>
    </div>

</form>