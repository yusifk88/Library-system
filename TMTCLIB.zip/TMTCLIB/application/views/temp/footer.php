


<div class="modal fade" id="modalContactForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog cascading-modal modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header bg-success white-text">
                <h4 class="title">
                    <i class="fa fa-pencil"></i> Add Book</h4>
                <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form action="" id="frmregbook">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="md-form form-sm">
                            <i class="fa fa-language prefix"></i>
                            <input required type="text" id="title" class="form-control form-control-sm" name="title">
                            <label for="title">Book Title</label>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 col-md-12">
                <div class="md-form form-sm">
                    <i class="fa fa-users prefix"></i>
                    <input required type="text" id="author" name="authors" class="form-control form-control-sm">
                    <label for="author">Author(s)</label>
                </div>
                    </div>
                    </div>


                <div class="row">
                    <div class="col-lg-4 col-md-4">
                <div class="md-form form-sm">
                    <i class="fa fa-star-half-empty prefix"></i>
                    <input required min="0" type="number" id="qty" name="qty" class="form-control form-control-sm">
                    <label for="qty">Copies</label>
                </div>
                    </div>


                    <div class="col-lg-4 col-md-4">
                <div class="md-form form-sm">
                    <i class="fa fa-balance-scale prefix"></i>
                    <input required type="text" id="qty" name="shelf" class="form-control form-control-sm">
                    <label for="shelf">Shelf</label>
                </div>
                    </div>

                    <div class="col-lg-4 col-md-4">
                <div class="md-form form-sm">
                    <i class="fa fa-hashtag prefix"></i>
                    <input required type="text" id="accno" name="accno" class="form-control form-control-sm">
                    <label for="accno">ACC No.</label>
                </div>
                    </div>
                    </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="md-form form-sm">
                            <i class="fa fa-barcode prefix"></i>
                            <input required type="text" id="isbn" name="isbn" class="form-control form-control-sm">
                            <label for="isbn">ISBN</label>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4 mb-2">
                    <button type="submit" class="btn btn-success">Send
                        <i class="fa fa-save ml-2"></i>
                    </button>
                </div>
            </form>

            </div>
        </div>
    </div>
</div>


</main>
<script src="<?=base_url()?>assets/js/jquery.min.js"></script>
<script src="<?=base_url()?>assets/js/popper.min.js"></script>
<script src="<?=base_url()?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?=base_url()?>assets/js/mdb.min.js"></script>
<script src="<?=base_url()?>assets/js/bootstrap-dialog.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.transit.min.js"></script>
<script src="<?=base_url()?>assets/js/snarl.min.js"></script>
<script src="<?=base_url()?>assets/js/wejs.js"></script>
</body>
</html>
