<!doctype html>
<html lang="en" style="width: 100%; height:100%;">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">
    <title>Tumu Midwifery Training College | Library</title>
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/mdb.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/snarl.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/bootstrap-dialog.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/dashboard.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
</head>
<body>
<input id="global_url" type="hidden" value="<?=base_url()?>">
<nav class="navbar navbar-dark sticky-top bg-success p-0">
    <a class="navbar-brand waves-effect pull-left waves-light col-sm-3 col-md-2 mr-0" style="vertical-align: middle; width: auto;" href="#">
      <h4>TMTC LIBRARY</h4>
        </a>
    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
            <a class="nav-link" href="" onclick="logout(); return false;"><i class="fa fa-sign-out"></i>Sign out</a>
        </li>
    </ul>
</nav>
<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 col-sm-3 col-xs-3 sidebar bg-white card hoverable" id="sidebar">
            <div class="sidebar-sticky pt-5">
                <ul class="nav  flex-column">
                    <li class="nav-item">
                        <a class="nav-link btn btn-block active" href="<?=base_url()?>index.php/app/#">
                            <i class="fa fa-dashboard fa-2x text-success ">
                                Dashboard <span class="sr-only">(current)</span>
                            </i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-block " href="<?=base_url()?>index.php/app/#managbooks/1">

                            <i class="fa fa-book fa-2x text-success">
                                Manage Books
                            </i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-block " href="<?=base_url()?>index.php/app/#lenhistory/1">
                            <i class="fa fa-history fa-2x text-success">
                                Lend History
                            </i>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link btn btn-block " href="<?=base_url()?>index.php/app/#useraccoun/">
                            <i class="fa fa-users fa-2x text-success">
                                User Accounts
                            </i>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        <main class="padding-left col-lg-12 col-md-12 col-sm-12 col-xs-12 pb-3 pt-1" id="main-content">
            <div id="dashboard" class="page_view animated slideInUp">

            </div>
            <div id="managbooks" class="page_view animated slideInUp">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="card">
                          <div class="card-header">
                              <div class="row">

                                  <div class="col-lg-1 col-md-1">
                                    <button onclick="print_book();" class="btn btn-outline-success btn-sm">Print</button>
                                  </div>
                                  <div class="col-lg-2 col-md-2">
                                    <button data-toggle="modal" data-target="#modalContactForm" class="btn btn-success btn-sm"><i class="fa fa-file"></i> add</button>
                                  </div>

                                  <div class="col-lg-6 col-md-6">
                                      <div class="md-form">
                                          <i class="fa fa-search prefix grey-text"></i>
                                          <input type="text" id="booksearch" class="form-control">
                                          <label for="booksearch" class="font-weight-light">Search...</label>
                                      </div>
                                  </div>

                              </div>

                          </div>

                          <div class="card-body" id="books_cont">

                          </div>
                      </div>
                    </div>
                </div>
            </div>
            <div id="lenhistory" class="page_view animated slideInUp">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="card">
                          <div class="card-header">
                              <div class="row">
                                  <div class="col-lg-2 col-md-2 ">
                                    <button onclick="print_lends();" class="btn btn-outline-success btn-sm">Print All</button>
                                  </div>

                                  <div class="col-lg-2 col-md-2 ">
                                    <button onclick="print_dlend();" class="btn btn-success btn-sm">Print Defaulters</button>
                                  </div>
                                  <div class="col-lg-8 col-md-8">
                                      <div class="md-form">
                                          <i class="fa fa-search prefix grey-text"></i>
                                          <input type="text" id="lendsearch" class="form-control">
                                          <label for="lendsearch" class="font-weight-light">Search...</label>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="card-body" id="lend_cont">

                          </div>
                      </div>
                    </div>
                </div>
            </div>


            <div id="useraccoun" class="page_view animated slideInUp">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="card">
                          <div class="card-header">
                              <div class="row">
                                  <div class="col-lg-2 col-md-2 ">
                                    <button onclick="adduser();" class="btn btn-outline-success btn-sm">Add User</button>
                                  </div>

                              </div>
                          </div>
                          <div class="card-body" id="user_cont">

                          </div>
                      </div>
                    </div>
                </div>
            </div>