<div class="table-responsive">
    <table class="table table-hover table-condensed">
    <thead class="bg-success text-white">
    <tr>
        <th>S/N</th>
        <th>Name</th>
        <th>Index No.</th>
        <th>Book Title</th>
        <th>Date Borrowed</th>
        <th>Expected <br> Return Date</th>
        <th>Return Status</th>
        <th class="text-center">Date Returned</th>
        <th colspan="2">Action</th>
    </tr>
    </thead>
        <tbody>
        <?php
                $i = 1;
            foreach($lends as $lend){
                ?>
                <tr class="<?=$lend->return_status ? 'alert-success':'alert-danger'?>"  id="lend_<?=$lend->id?>">
                    <td><?=$i?></td>
                    <td><?=highlight_phrase($lend->stname, $search, '<span style="background-color:greenyellow;">', '</span>');?></td>
                    <td><?=$lend->stid?></td>
                    <td><?=highlight_phrase($lend->title, $search, '<span style="background-color:greenyellow;">', '</span>');?></td>
                    <td><?=$lend->dlend?></td>
                    <td><?=$lend->dreturn?></td>
                    <td><?=$lend->return_status?'Returned':'Not Returned'?></td>
                    <td class="text-center"><?=$lend->return_date?$lend->return_date : ' - '?></td>
                    <td class="text-center">
                        <?php
                        if(!$lend->return_status) {
                            ?>
                            <button class="btn btn-outline-success btn-sm bg-white"
                                    onclick="return_book(<?= $lend->id ?>)">
                                Receive <br> Book
                            </button>
                            <?php
                        }else{
                            ?>
                            <i class="fa fa-thumbs-o-up text-success fa-2x"> </i>
                            <?php
                        }

                        ?>
                    </td>
                    <td>
                        <button onclick="dellend(<?=$lend->id?>)" class="btn btn-outline-danger btn-sm">
                            <i class="fa fa-remove"></i>
                        </button>
                    </td>
                </tr>
                <?php
            $i++;
            }
        ?>
        </tbody>
    </table>
</div>
<?php
$next = $page+1;
$prev = $page -1;

if($pages>1){
    if($page > 1) {
        ?>
        <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#lenhistory/1">First Page</a>
        <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#lenhistory/<?= $prev ?>"><<
            Prev.</a>
        <?php
    }
    for($i =1; $i<=$pages;$i++){
        if($page == $i){
            ?>
            <a  class="btn btn-success btn-sm">Page <?=$i?></a>
            <?php
        }else{
            ?>
            <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#lenhistory/<?=$i?>">Page<?=$i?></a>

            <?php
        }}
    if($page <$pages) {
        ?>
        <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#lenhistory/<?= $next ?>">Next
            >> </a>
        <a class="btn btn-outline-success btn-sm" href="http://localhost/tmtclib/index.php/app/#lenhistory/<?= $pages ?>">Last
            Page</a>
        <?php
    }}
?>