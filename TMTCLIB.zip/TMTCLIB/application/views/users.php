
<div class="table-responsive">
    <table class="table table-hover table-striped table-condensed">
        <thead class="bg-success text-white">
            <th>S/N</th>
            <th>USER NAME</th>
            <th>PASSWORD</th>
            <th>ACTION</th>
        </thead>
        <tbody>
            <?php
            $i=1;
                foreach($users as $user){
                    if($uname == $user->uname){
                        ?>
                        <tr class="bg-light text-muted">
                            <td><?=$i?></td>
                            <td><?=$user->uname?></td>
                            <td><?=$user->upass?></td>
                            <td>
                            <em>Current User</em>
                            </td>
                        </tr>

                        <?php
                    }else{
                    ?>
                    <tr id="urow_<?=$user->id?>">
                        <td><?=$i?></td>
                        <td><?=$user->uname?></td>
                        <td><?=$user->upass?></td>
                        <td>
                            <button onclick="deluser(<?=$user->id?>)" class="btn btn-outline-danger btn-sm"><i class="fa fa-remove"></i></button>
                        </td>
                    </tr>
                    <?php
                    $i++;
                }}
            ?>
        </tbody>
    </table>
</div>