<div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12">
        <form action="" id="lend_form" onsubmit="savelend(); return false;">
            <input type="hidden" name="bid" value="<?=$book->id?>">
        <div class="md-form form-sm">
            <i class="fa fa-user prefix"></i>
            <input value="" required type="text" id="stname" class="form-control form-control-sm" name="stname">
            <label for="stname">Student Name</label>
        </div>
        <div class="md-form form-sm">
            <i class="fa fa-id-badge prefix"></i>
            <input value="" required type="text" id="stindex" class="form-control form-control-sm" name="stindex">
            <label for="stindex">Index Number</label>
        </div>
        <div class="md-form form-sm">
            <i class="fa fa-calendar-check-o prefix"></i>
            <input value="" required type="date" id="lenddate" class="form-control form-control-sm" name="lenddate">
            <label class="active" for="lenddate">Lend Date</label>
        </div>
        <div class="md-form form-sm">
            <i class="fa fa-calendar-plus-o prefix"></i>
            <input value="" required type="date" id="erdate" class="form-control form-control-sm" name="erdate">
            <label class="active" for="erdate">Expected return Date</label>
        </div>
        <div class="card">
            <div class="card-body" id="lendhist">
            <small class="text-muted">Student's lend history would show here</small>
            </div>
        </div>
        </form>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12">
        <ul class="list-group">
            <li class=" list-group-item"><strong><?=$book->title?></strong><br><small>Title</small></li>
            <li class=" list-group-item"><strong><?=$book->authors?></strong><br><small>Author(s)</small></li>
            <li class=" list-group-item"><strong><?=$book->shelf?></strong><br><small>Shlef/Location</small></li>
            <li class=" list-group-item"><strong><?=$book->accno?></strong><br><small>Access Number</small></li>
            <li class=" list-group-item"><strong><?=($book->copies-($book->nummissing + $book->numdamage+$book->numlent))?> Copies</strong><br><small>Available Copies</small></li>
        </ul>
    </div>
</div>
<script>
    $("#stindex").keyup(function () {
        var stid = $("#stindex").val();
        $
            .get(get_url()+"app/lend_history?stid="+stid)
            .done(function (data){
                $("#lendhist").html(data);

            });

    });

</script>