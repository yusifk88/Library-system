var view_name = "#main-content";
$(document).ready(function(){

    $('button').tooltip();

      $("#booksearch").keyup(function () {
        get_books(get_paerimeter());

    });

    $("#lendsearch").keyup(function () {
        lenhistory(get_paerimeter());

    });



    $("#frmregbook").submit(function () {
        var data = $("#frmregbook :input").serializeArray();
        $
            .post(get_url()+"app/savebook",data)
            .done(function () {
            get_books(get_paerimeter());
            });
        return false;
    });

    $(window).on('hashchange',function(e){
        var temptag = window.location.hash;
        var claentag = temptag.replace('#','');
        var parameter;
        if(claentag.length>10){
         parameter = claentag.substr(claentag.indexOf("/")+1,claentag.substr(claentag.indexOf("/")).length);
          var realtag = claentag.substr(0,10);
            var tag = {
                name: realtag
            };
        }else {
            var tag = {
            name: window.location.hash.replace('#/', '')
            };
        }
        if(tag.name.length>0){
            localStorage.viewid = '#'+tag.name;
            $(".page_view").hide();
            $("#"+tag.name).show();

            window[tag.name](parameter);
        }else{
            $(".page_view").hide();
            $("#dashboard").show();
        getdashboard();
        }
    }).trigger('hashchange');
});

function get_paerimeter(){

    var temptag = window.location.hash;
    var claentag = temptag.replace('#','');
    var parameter;
        parameter = claentag.substr(claentag.indexOf("/")+1,claentag.substr(claentag.indexOf("/")).length);
      return parameter;
}




function get_books(index){

    $("#books_cont").html("<i class='fa fa-circle-o-notch fa-2x fa-spin text-success'></i> Please Wait....");
    $
    .get(get_url()+"app/getbooks?page="+index+"&search="+$("#booksearch").val())
    .done(function (data) {

            $("#books_cont").html(data)
        });
}

function useraccoun(index){
$("#user_cont").html("<i class='fa fa-circle-o-notch fa-3x text-success fa-spin'></i> PLease Wait...")

$
    .get(get_url()+"app/getusers")
    .done(function (data) {
    $("#user_cont").html(data);
    });
}
function adduser(){
    var temp = '<div class="md-form form-sm">  <i class="fa fa-user prefix"></i><input value="" required min="0" type="text" id="uname" name="uname" class="form-control form-control-sm"><label for=uname">User Name</label></div>';
     temp += '<div class="md-form form-sm">  <i class="fa fa-asterisk prefix"></i><input value="" required min="0" type="password" id="upass" name="upass" class="form-control form-control-sm"><label for="upass">Password</label></div>';
     temp += '<div class="md-form form-sm">  <i class="fa fa-asterisk prefix"></i><input value="" required min="0" type="password" id="cpass" name="cpass" class="form-control form-control-sm"><label for="cpass">Confirm Password</label></div>';

    BootstrapDialog.show({
        title:"Add New User",
        message:temp,
        type:"type-success",
        buttons:[{label:"CREATE USER",cssClass:"btn-outline-success btn-block",action: function (d) {
            var data={
                uname:$("#uname").val(),
                upass:$("#upass").val(),
                cpass:$("#cpass").val()
            };

            if(!data.uname || !data.upass  || !data.cpass){

                Snarl.addNotification({
                    title:"ERROR",
                    text:"A required field is empty"
                });

                $(".snarl-notification").addClass('bg-danger text-white');


            }else{

                if(data.upass == data.cpass){

                $
                    .post(get_url()+"app/adduser",data)
                    .done(function () {

                        d.close();
                        useraccoun(get_paerimeter());
                    });
                }else{

                    Snarl.addNotification({
                        title:"ERROR",
                        text:"Passwords do not match, please confirm password"
                    });

                    $(".snarl-notification").addClass('bg-danger text-white');



                }



            }


        }}]


    });


}

function getdashboard(){
$
    .get(get_url()+"app/getdashboard")
    .done(function (dash) {
      $("#dashboard").html(dash);
    });
}


function get_url(){
return $("#global_url").val()+"index.php/";
}

function managbooks(prmter){

get_books(prmter);

}

function showsearch(){
     $("#global_seach").fadeIn(100);
}
function showsearch(){
    $("#global_seach").fadeOut(100);
}


function search_val(){

    return $("#global_seach").val();

}
//----------------------------------------content functions---------------------------------------------------------


function restorebak(viewid){

$("#backupfile").val("");

}

function printglist(){

    var inp = "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>";
    inp+="<label class='control-label'>Document heading</label>"
    inp+="<textarea id='doctitle' placeholder='define a custom title for this document' class='form-control'></textarea>"
    inp+="</div></div>";

    BootstrapDialog.show({
        title:"Print General Staff List",
        message:inp,
        buttons:[{label:"View & Print",cssClass:"btn-good",action:function(d){
            d.close();
            window.open("./printer/genlist/?title="+$("#doctitle").val(),"General Staff List","outerHeight=800px,outerWidth=800px,innerHeight=750px,innerWidth=750px,menubar=yes,scrollbars=yes");
        }}]
    });
}


function printstatlist(){
    var stat_array = ['Active','Study Leave with pay','Study leave without pay','vacation of post','Diseased','Embargo','Maternity Leave','Exam Leave','Casual Leave','Annual Leave','Sick Leave','Bereavement Leave'];
    $.getJSON("./app/getstatdatejson/",function(dt){
        var inp = "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>";
        inp+="<label class='control-label'>Year</label>";
        inp+="<select class='form-control' id='year'>";
        var j =0;
        for(var x =0;x<dt.length;x++) {
           j++;
            if(j<dt.length){
                var ls = dt[x].dentry.substr(0,4);
                var gr = dt[j].dentry.substr(0,4);
           if (!(ls == gr)) {

            inp += "<option value='"+ ls +"'>" +ls+ "</option>";

            }
            }else{

                inp += "<option value='"+ dt[x].dentry.substr(0,4) +"'>" +dt[x].dentry.substr(0,4)+ "</option>";

            }
        }
        inp+="</select></div></div>";
    inp += "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>";
    inp+="<label class='control-label'>Select Status</label>";
    inp+="<select class='form-control' id='stat'>";
    for(var i =0;i<stat_array.length;i++){
        inp+="<option   value='"+i+"'>"+stat_array[i]+"</option>"
    }
    inp+="</select></div></div>";
    inp += "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>";
    inp+="<label class='control-label'>Document heading</label>"
    inp+="<textarea id='doctitle' placeholder='define a custom title for this document' class='form-control'></textarea>"
    inp+="</div></div>";
    BootstrapDialog.show({
        title:"Print General Staff List",
        message:inp,
        buttons:[{label:"View & Print",cssClass:"btn-good",action:function(d){
            d.close();
            window.open("./printer/statlist/?title="+$("#doctitle").val()+"&status="+$("#stat").val()+"&year="+$("#year").val(),"General Staff List","outerHeight=800px,outerWidth=800px,innerHeight=750px,innerWidth=750px,menubar=yes,scrollbars=yes");
        }}]
    });
    });
}

function print_list(){
    var inp = "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>";
    inp+="<label class='control-label'>Document heading</label>"
    inp+="<textarea id='doctitle' placeholder='define a custom title for this document' class='form-control'></textarea>"
    inp+="</div></div>";
    BootstrapDialog.show({
        title:"Print Filtered List",
        message:inp,
        buttons:[{label:"View & Print",cssClass:"btn-good",action:function(d){
            d.close();
            window.open("./printer/stafflist/?status="+$("#filter-status").val()+"&rank="+$("#filter_rank").val()+"&post="+$("#filter_post").val()+"&sex="+$("#filter_sex").val()+"&title="+$("#doctitle").val(),"Staff List","outerHeight=800px,outerWidth=800px,innerHeight=750px,innerWidth=750px,menubar=yes,scrollbars=yes");


        }}]


    });



}


function showdet(detid){

$(detid).slideToggle(100);
}



function logout(){
BootstrapDialog.show({
    title:"Confirm Log out",
    message:"Are you sure you want to log out of the system ?",
    type:"type-danger",
    buttons:[{label:"LOG OUT",cssClass:'btn-outline-danger',action:function(){

        $.get(get_url()+"app/logout",function(){

           window.location= get_url()+"app/login";
        });


    }}]

});
}


var edit_dlg;

function edit_book(id){

edit_dlg =  BootstrapDialog.show({
    title:"Edit this Book",
    message:"<div id='editcont'><i class='fa fa-circle-o-notch fa-spin fa-3x text-success'></i> Please wait...</div>",
    type:'type-success',
    size:'size-wide',
    buttons:[{label:"SAVE CHANGES",cssClass:'btn-outline-success',action: function (d) {
        savechanges();

    }},
        {label:"CANCEL",cssClass:'btn-outline-danger',action: function (d) {

            d.close();
        }}],
    closable:false,
    onshown: function () {
        $
            .get(get_url()+"app/geteditbook/"+id)
            .done(function (data) {
            $("#editcont").html(data);
            }).error(function () {

                $("#editcont").html('<div class="alert alert-danger">Sorry we could not load data please try again</div>');

            });

    }



});

}



function savechanges(){
    var book = $("#frmeditbook :input").serializeArray();
  $
    .post(get_url()+"app/savechanges",book)
    .done(function () {
    edit_dlg.close();
          get_books(get_paerimeter());

      });
}


function change_damaged(id,copies,numd){
BootstrapDialog.show({
    title:"Record Damaged Copies",
    message:"<div class='md-form form-sm'><i class='fa fa-star-half-empty prefix'></i><input readonly value='"+copies+"' required min='0' type='number' id='dqty' name='dqty' class='form-control form-control-sm'><label class='active' for='dqty'>AvailableCopies</label></div> <div class='md-form form-sm'><i class='fa fa-warning prefix'></i><input value='"+numd+"' required min='0' type='number' id='numd' name='numd' class='form-control form-control-sm'><label class='active' for='numd'>Number Damaged</label></div>",
    type : 'type-success',
    buttons: [{label:"SAVE CHANGES",cssClass:'btn-outline-success',action: function (d) {
       var cop = $("#dqty").val();
       var numd = $("#numd").val();
        var data = {
            id:id,
            copies:cop,
            numd:numd
        };
        if(Number(numd) > Number(cop)){
            Snarl.addNotification({
                title:"ERROR",
                text:"Number damaged cannot be bigger than copies "
            });

        $(".snarl-notification").addClass('bg-danger text-white');

        }else{
            $
            .post(get_url()+"app/change_damaged",data)
            .done(function () {
                    d.close();
               get_books(get_paerimeter());

            });
        }
        
    }}]
});

}

function change_missing(id,copies,nummis){
    BootstrapDialog.show({
        title:"Change Missing Copies",
        message:"<div class='md-form form-sm'><i class='fa fa-star-half-empty prefix'></i><input readonly value='"+copies+"' required min='0' type='number' id='dqty' name='dqty' class='form-control form-control-sm'><label class='active' for='dqty'>Available Copies</label></div> <div class='md-form form-sm'><i class='fa fa-warning prefix'></i><input value='"+nummis+"' required min='0' type='number' id='nummis' name='nummis' class='form-control form-control-sm'><label class='active' for='numd'>Number Missing</label></div>",
        type : 'type-warning',
        buttons: [{label:"SAVE CHANGES",cssClass:'btn-outline-success',action: function (d) {
            var cop = $("#dqty").val();
            var nummis = $("#nummis").val();
            var data = {
                id:id,
                copies:cop,
                nummis:nummis
            };
            if(Number(nummis) > Number(cop)){
                Snarl.addNotification({
                    title:"ERROR",
                    text:"Number damaged cannot be bigger than copies "
                });

                $(".snarl-notification").addClass('bg-danger text-white');

            }else{
            $
                .post(get_url()+"app/change_missing",data)
                .done(function(){
                    d.close();
                    get_books(get_paerimeter());

                });
            }

        }}]

    });

}

function deluser(id){
    BootstrapDialog.show({
        title:"confirm delete",
        message:"This user will not be able to use the app again, PROCEED?",
        type:"type-danger",
        buttons:[{label:"PROCEED",cssClass:"btn-outline-danger",action: function (d) {
            $
            .get(get_url()+"app/deluser/"+id)
            .done(function () {
                    var urow = "#urow_"+id;
                    $(urow).fadeOut(100).remove();
                    d.close();
                });
        }}]



    });




}


function print_book()
{
    window.open(get_url()+"app/printbook","Book List","outerHeight=800px,outerWidth=800px,innerHeight=750px,innerWidth=750px,menubar=yes,scrollbars=yes");
}

function print_lends()
{
    window.open(get_url()+"app/printlends","Lend Historyy","outerHeight=800px,outerWidth=800px,innerHeight=750px,innerWidth=750px,menubar=yes,scrollbars=yes");
}
function print_dlend()
{
    window.open(get_url()+"app/printdlend","Lend Historyy","outerHeight=800px,outerWidth=800px,innerHeight=750px,innerWidth=750px,menubar=yes,scrollbars=yes");
}

function del_book(id){
    BootstrapDialog.show({
        title:"Delete this book",
        message:"ARE YOU SURE YOU WANT TO DELETE THIS BOOK?",
        type:"type-danger",
        buttons:[{label:'DELETE',cssClass:'btn-outline-danger',action: function (d) {
            $
                .get(get_url()+"app/delbook?id="+id)
                .done(function () {
                    var row = "#brow_"+id;
                    $(row).fadeOut(200).remove();
                    d.close();
                });
        }}]

    });
}
function savelend(){
var lenddata = $("#lend_form :input").serializeArray();

    if(!lenddata[1].value || !lenddata[2].value || ! lenddata[3].value || !lenddata[4].value){
        Snarl.addNotification({
            title:"ERROR",
            text:"You have not entered a required field"
        });
        $(".snarl-notification").addClass('bg-danger text-white');
    }else{


        $
            .post(get_url()+"app/savelend",lenddata)
            .done(function () {
                get_books(get_paerimeter());
                lend_dlg.close();

                Snarl.addNotification({
                    title:"SAVED ",
                    text:"Book lent successfully"
                });
                $(".snarl-notification").addClass('bg-success text-white');

            });
    }


}

var lend_dlg;

function lend_book(id){
lend_dlg =BootstrapDialog.show({
        title:"Lend This Book",
        message:"<div id='lend-cont'> <i class='fa fa-circle-o-notch fa-2x fa-spin text-success'></i> Please Wait.... </div>",
        type:"type-success",
        size:"size-wide",
        closable:false,
        buttons:[{label:"LEND BOOK",cssClass:"btn-outline-success",action: function () {

            $("#lend_form").submit();

        }},{label:"CANCEL",cssClass:"btn-outline-danger",action: function (d) {
            d.close();
        }}],
        onshown: function () {
          $
            .get(get_url()+"app/getlendinput?bid="+id)
            .done(function (data) {
            $("#lend-cont").html(data);
          });
        }
    });
}


function lenhistory(index){
    $("#lend_cont").html("<i class='fa fa-circle-o-notch fa-2x fa-spin text-success'></i> Please Wait....");
$
    .get(get_url()+"app/getlend?search="+$("#lendsearch").val()+"&page="+index)
    .done(function (data) {
        $("#lend_cont").html(data);
   });
}

function return_book(id){
BootstrapDialog.show({
    title:"Receive This Book",
    message:"<div id='rbook-cont'><i class='fa fa-circle-o-notch fa-2x text-success fa-spin'></i> Please Wait...</div>",
    type:"type-success",
    size:'size-wide',
    closable:false,
    buttons:[{label:"RECEIVE BOOK",cssClass:"btn-outline-success",action: function (d) {
        var rdate = $("#rdate").val();
        if(rdate){
        var data = {
            id:id,
            rdate:rdate
        };
            $
            .post(get_url()+"app/return_book",data)
            .done(function () {
                    d.close();
                    lenhistory(get_paerimeter());

                    Snarl.addNotification({
                        title:"SAVED",
                        text:"Book received successfully"
                    });
                    $(".snarl-notification").addClass('bg-success text-white');
            });



        }else{
            Snarl.addNotification({
                title:"ERROR",
                text:"Please select the date this book was returned"
            });
            $(".snarl-notification").addClass('bg-danger text-white');

        }


    }},{label:"CANCEL",cssClass:"btn-outline-danger",action: function (d) {
        d.close();
    }}],
    onshown: function () {

        $
            .get(get_url()+"app/getrbook_input/"+id)
            .done(function (data) {

                $("#rbook-cont").html(data);

            });

    }

});

}



function dellend(id){
BootstrapDialog.show({
title:"CONFIRM DELETE",
message:"DO YOU WANT TO DELETE THIS RECORD?",
type:"type-danger",
    buttons:[{label:"DELETE",cssClass:"btn-outline-danger",action: function (d) {
        $
        .get(get_url()+"app/dellend?id="+id)
        .done(function (){
                var lend_row = "#lend_"+id;
                $(lend_row).fadeOut(100).remove();
                d.close();
        });
        d.close();
    }}],

});

}